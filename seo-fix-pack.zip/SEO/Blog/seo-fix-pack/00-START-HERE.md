# 先看这里 · SEO 修复包（直接发程序员）

线上博客页 On-Page SEO 报红：**Canonical / Meta Description / Social Media / Meta Title**。
实测原因：部署只注入了 `<title>` + `ld+json`，**没注入** canonical / description / og / twitter，
页面用了站点默认 `<head>`。内容本身没问题，是 `<head>` 注入不全。

## 三步修复

1. **读** `PROGRAMMER-SEO-DEPLOY.md`（完整说明 + 实测诊断表）。
2. **注入**：对每篇 `/en/blog/{slug}`，把 `head/{slug}.html` 整段插入页面 `<head>`。
   - 它已含 canonical + meta description(150–160) + og:* + twitter:* + JSON-LD，且 `<title>` 已是 40–60 字符。
   - 程序化做法：读 `seo-meta.json`（按 slug 取 `canonical / meta_description / og.* / twitter.* / title`）。
3. **验证**：`curl -s https://infinisynapse.com/en/blog/{slug} | grep -i canonical`，应能看到 canonical；
   再用 QuickCreator On-Page 复查，四项转绿。

## 文件清单

| 文件 | 用途 |
|---|---|
| `部署清单-完整URL.csv` | **按优先级排序的 100 篇部署清单**（完整 URL + 周次 + 状态 + head 片段） |
| `PROGRAMMER-SEO-DEPLOY.md` | 主文档（实测诊断 + 注入方案 + Next.js 示例） |
| `QUICKCREATOR-SEO-FIX.md` | 若用 QuickCreator 后台手填，逐字段对照 |
| `seo-meta.json` | 100 篇 SEO 元数据（按 slug，程序化注入用） |
| `quickcreator-seo-fields.csv` | 同上，CSV 逐字段（人工填用） |
| `blog-index-import-master.json` | 列表页数据（标题/摘要/分类/URL=/en/blog/slug） |
| `blog-cms-import-100.csv` | 列表数据 CSV 版 |
| `head/{slug}.html` | **每篇的 `<head>` 片段**（直接注入） |

## 注意

- URL 规范：`https://infinisynapse.com/en/blog/{slug}`（英文，无尾斜杠）。
- 页面 `<h1>` 用标题渲染，正文不要再放 `# H1`（避免双 H1）。
- 不要改 `head.html` 里的 URL / FAQ / canonical。
- 图片未包含在本包（已在线上 CDN）；如需原图见完整包 `frontend-package.zip`。
